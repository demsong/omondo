import 'package:smart_admin_dashboard/core/constants/color_constants.dart';
import 'package:smart_admin_dashboard/screens/dashboard/components/calendart_widget.dart';
import 'package:smart_admin_dashboard/screens/dashboard/components/charts.dart';
import 'package:smart_admin_dashboard/screens/dashboard/components/user_details_mini_card.dart';
import 'package:flutter/material.dart';

import '../../../core/widgets/input_widget.dart';
import '../../forms/components/add_new_widget.dart';



class UserDetailsWidget extends StatefulWidget {
  // const UserDetailsWidget({Key? key}) : super(key: key);

  @override
  _UserDetailsWidgetState createState() => _UserDetailsWidgetState();
}

class _UserDetailsWidgetState extends State<UserDetailsWidget> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
  
}

  // const UserDetailsWidget({
  //   Key? key,
  // }) : super(key: key);
  var items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
  ];
  String dropdownvalue = 'Item 1';
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(defaultPadding),
      decoration: BoxDecoration(
        color: secondaryColor,
        borderRadius: const BorderRadius.all(Radius.circular(10)),
      ),
      child: Column(

        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          DropdownButton(

            // Initial Value
            value: dropdownvalue,

            // Down Arrow Icon
            icon: const Icon(Icons.keyboard_arrow_down),

            // Array list of items
            items: items.map((String items) {
              return DropdownMenuItem(
                value: items,
                child: Text(items),
              );
            }).toList(),
            // After selecting the desired option,it will
            // change button value to selected value
            onChanged: (String? value) {
              // This is called when the user selects an item.
              setState(() {
                dropdownValue = value!;
              });
            },
          ),
          InputWidget(
            topLabel: "Nom",
            obscureText: true,
            hintText: "Entrez votre nom",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),
          SizedBox(height: 8.0),
          InputWidget(
            topLabel: "Prenom",
            obscureText: true,
            hintText: "Enter votre prenom",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Commune",
            obscureText: true,
            hintText: "Enter votre commune",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Profession",
            obscureText: true,
            hintText: "Enter votre profession",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "sexe",
            obscureText: true,
            hintText: "choisir votre sexe",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Type de Visa ",
            obscureText: true,
            hintText: "Choisir votre type de visa",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Consultation payé?",
            obscureText: true,
            hintText: "Select",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Statut matrimonial ",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Avez vous un passeport valide ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Si oui quelle est la date d'expiration ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Avez vous un casier judiciaire?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Avez vous des soucis de santé?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Avez vous des enfants ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Si oui, quel est l'âge de vos enfants ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Niveau de scolarité",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Nombre d'années d'expérience professionnelle ",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Disposez vous d'une offre d'emploi validée ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),
          SizedBox(height: 30.0),
          Text("CARACTÉRISTIQUE DE L'EPOUX, DU CONJOINT DE FAIT OU DES ENFANTS QUI ACCOMPAGNENT CONJOINT / EPOUX / EPOUSE"),
          SizedBox(height: 24.0),
          InputWidget(
            topLabel: "Quel est son niveau de scolarité ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Quel est votre domaine de formation ?	",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Quel est votre âge ?	",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),SizedBox(height: 30.0),
          Text("CONNAISSANCES LINGUISTIQUES"),
          SizedBox(height: 24.0),
          InputWidget(
            topLabel: "Niveau en français",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Niveau en anglais",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Quel est l'âge de vos enfants ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Quel est leur niveau de scolarité ?",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Password",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),InputWidget(
            topLabel: "Password",
            obscureText: true,
            hintText: "Enter Password",
            onSaved: (String? uPassword) {},
            onChanged: (String? value) {},
            validator: (String? value) {},
          ),
          InputWidget(
            keyboardType: TextInputType.emailAddress,
            onSaved: (String? value) {},
            onChanged: (String? value) {
            },
            validator: (String? value) {
              return (value != null && value.contains('@'))
                  ? 'Do not use the @ char.'
                  : null;
            },

            topLabel: "Name",

            hintText: "Enter Name",
            // prefixIcon: FlutterIcons.chevron_left_fea,
          ),
          SizedBox(height: 8.0),
        ],
      ),
    );
  }
