// import 'dart:js';
// import 'package:http/http.dart' as http;
// import 'package:smart_admin_dashboard/core/constants/color_constants.dart';
// import 'package:smart_admin_dashboard/screens/dashboard/components/calendart_widget.dart';
// import 'package:smart_admin_dashboard/screens/dashboard/components/charts.dart';
// import 'package:smart_admin_dashboard/screens/dashboard/components/user_details_mini_card.dart';
// import 'package:flutter/material.dart';
//
// import '../../forms/components/add_new_widget.dart';
// //
// // class UserDetailsWidget extends StatelessWidget {
// //   // const UserDetailsWidget({
// //   //   Key? key,
// //   // }) : super(key: key);
//   class UserDetailsWidget extends StatefulWidget {
//
//   UserDetailsWidget({
//   // super.key,
//   required this.parameter,
//   });
//
//   final parameter;
//
//   @override
//   _UserDetailsWidgetState createState() => _UserDetailsWidgetState();
//   }
//
//   class _UserDetailsWidgetState extends State<UserDetailsWidget> {
//
//   TextEditingController controllerNom = TextEditingController();
//   TextEditingController controllerPrennom = TextEditingController();
//   TextEditingController controllersexe = TextEditingController();
//   TextEditingController controllerage = TextEditingController();
//   bool _isLoading = false;
//   bool _isInserting = false;
//
//
//   @override
//   void initState(){
//     super.initState();
//
//     // Additional initialization of the State
//   }
//
//   @override
//   void didChangeDependencies(){
//     super.didChangeDependencies();
//
//     // Additional code
//   }
//
//   @override
//   void dispose(){
//     // Additional disposal code
//
//     super.dispose();
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.all(defaultPadding),
//       decoration: BoxDecoration(
//         color: secondaryColor,
//         borderRadius: const BorderRadius.all(Radius.circular(10)),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         // children: [
//         //   Text("mettre le formulaire dans ce children"),
//         //   // CalendarWidget(),
//         //   // Text(
//         //   //   "Employment Details",
//         //   //   style: TextStyle(
//         //   //     fontSize: 18,
//         //   //     fontWeight: FontWeight.w500,
//         //   //   ),
//         //   // ),
//         //   SizedBox(height: defaultPadding),
//         //   // Chart(),
//         //   // UserDetailsMiniCard(
//         //   //   color: Color(0xff0293ee),
//         //   //   title: "Technical Interview",
//         //   //   amountOfFiles: "%28.3",
//         //   //   numberOfIncrease: 1328,
//         //   // ),
//         //   // UserDetailsMiniCard(
//         //   //   color: Color(0xfff8b250),
//         //   //   title: "HR Interview",
//         //   //   amountOfFiles: "%16.7",
//         //   //   numberOfIncrease: 1328,
//         //   // ),
//         //   // UserDetailsMiniCard(
//         //   //   color: Color(0xff845bef),
//         //   //   title: "Final Interview",
//         //   //   amountOfFiles: "%22.4",
//         //   //   numberOfIncrease: 1328,
//         //   // ),
//         //   // UserDetailsMiniCard(
//         //   //   color: Color(0xff13d38e),
//         //   //   title: "Rejected",
//         //   //   amountOfFiles: "%2.3",
//         //   //   numberOfIncrease: 140,
//         //   // ),
//         // ],
//
//         children: [
//           //imageProfile(),
//           const SizedBox(height: 35,),
//           buildTextField(1,"Libellé", "libellé de la tâche", false, controllerNom),
//           buildTextField(5,"Prennom", "Petite Prennom de la tâche", false, controllerPrennom),
//           buildTextField(2,"sexe", "Nécéssité de la tâche", false, controllersexe),
//           // date de modiffication vien automatiquement
//           //buildTextField(1,"Durée de la tâche", "combien d'heures/jours...", false, controllerDuree),
//           buildTextField(2,"age de la tâche", "les noms des techniciens qui participerons", false, controllerage),
//           //buildCustomComboBoxFieldUser("age de la tâche", listUser, Icons.arrow_drop_down_outlined),
//        const SizedBox(height: 35,),
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               OutlinedButton(
//                 style: OutlinedButton.styleFrom(
//                   padding: const EdgeInsets.symmetric(horizontal: 50),
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//                 ),
//                 onPressed: () { Navigator.of(context).pop(); },
//                 child: const Text("Annuler", style: TextStyle(fontSize: 12, letterSpacing: 2.2, color: Colors.black)),
//               ),
//               ElevatedButton.icon(
//                 style: ElevatedButton.styleFrom(
//                   backgroundColor: const Color(0xff696b9e),
//                   padding: const EdgeInsets.symmetric(horizontal: 30),
//                   elevation: 2,
//                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
//                 ),
//                 onPressed: () {
//                   addData();
//                 },
//                 icon: _isInserting
//                     ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2,)
//                     : const Icon(Icons.perm_contact_cal_outlined),
//                 label: const Text("Enregistrer", style: TextStyle(fontSize: 12, letterSpacing: 1.5, color: Colors.white),),
//               )
//             ],
//           )
//         ],
//       ),
//     );
//   }
//   Widget buildTextField(int nb, String labelText, String placeholder, bool isPasswordTextField, TextEditingController textEditingController) {
//     return Padding(
//       padding: const EdgeInsets.only(bottom: 35.0),
//       child: TextField(
//         maxLines: nb,
//         controller: textEditingController,
//         //obscureText: isPasswordTextField ? showPassword : false,
//         decoration: InputDecoration(
//             suffixIcon: isPasswordTextField
//                 ? IconButton(
//               onPressed: () {},
//               icon: const Icon(Icons.remove_red_eye, color: Colors.grey,),
//             )
//                 : null,
//             contentPadding: const EdgeInsets.only(bottom: 3),
//             labelText: labelText,
//             labelStyle: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black,),
//             floatingLabelBehavior: FloatingLabelBehavior.always,
//             hintText: placeholder,
//             hintStyle: const TextStyle(fontSize: 13, color: Colors.black,)
//         ),
//       ),
//     );
//   }
//
//   void addData() async {
//     setState(() {
//       _isInserting = true;
//     });
//     if (controllerNom.value.text.isEmpty) {
//       setState(() {
//         error(context, "Nom");
//       });
//       await Future.delayed(const Duration(seconds: 2));
//       setState(() {
//         _isInserting = false;
//       });
//     } else if (controllerPrennom.value.text.isEmpty) {
//       setState(() {
//         error(context, "Donner une briève Prennom de la tache");
//       });
//       await Future.delayed(const Duration(seconds: 2));
//       setState(() {
//         _isInserting = false;
//       });
//     } else if (controllersexe.value.text.isEmpty) {
//       setState(() {
//         error(context, "Entrer le sexe de la tache");
//       });
//       await Future.delayed(const Duration(seconds: 2));
//       setState(() {
//         _isInserting = false;
//       });
//     }else if (controllerDateDebut.value.text.isEmpty) {
//       setState(() {
//         error(context, "Quelle est la date de debut de la tache ?");
//       });
//       await Future.delayed(const Duration(seconds: 2));
//       setState(() {
//         _isInserting = false;
//       });
//     }
//       await Future.delayed(const Duration(seconds: 2));
//       setState(() {
//         _isInserting = false;
//       });
//     }
//   void error(BuildContext context, String error) {
//     final scaffold = ScaffoldMessenger.of(context);
//     scaffold.showSnackBar(
//       SnackBar(
//         content: Text(error,style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20.0,)),
//         action: SnackBarAction(
//             label: 'OK', onPressed: scaffold.hideCurrentSnackBar),
//       ),
//     );
//   }
//
//   }
