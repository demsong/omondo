import 'package:smart_admin_dashboard/core/constants/color_constants.dart';
import 'package:smart_admin_dashboard/responsive.dart';

import 'package:smart_admin_dashboard/screens/dashboard/components/mini_information_card.dart';

import 'package:smart_admin_dashboard/screens/dashboard/components/recent_forums.dart';
import 'package:smart_admin_dashboard/screens/dashboard/components/recent_users.dart';
import 'package:smart_admin_dashboard/screens/dashboard/components/user_details_widget.dart';
import 'package:flutter/material.dart';

import '../../../core/widgets/input_widget.dart';
import '../../dashboard/components/header.dart';

class EnregistrerClientContenu extends StatefulWidget {
  @override
  State<EnregistrerClientContenu> createState() => _EnregistrerClientContenuState();
}

class _EnregistrerClientContenuState extends State<EnregistrerClientContenu> {
  late bool selected;
  late List<String> check;
  late bool enabled;
  late String dropdownValue;
  TextEditingController emailEditingController=TextEditingController();
  @override
  void initState() {
    selected = false;
    check = ['oui','non'];
    dropdownValue = 'oui';
    if (dropdownValue=="oui"){
      enabled = true;
    }
    else{
      enabled = false;
    }
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        //padding: EdgeInsets.all(defaultPadding),
        child: Container(
          padding: EdgeInsets.all(defaultPadding),
          child: Column(
            children: [
              Header(),
              SizedBox(height: defaultPadding),
            Card(
              color: secondaryColor,
              elevation: 5,
              margin: EdgeInsets.fromLTRB(32, 32, 64, 32),
              child: Padding(
                padding: const EdgeInsets.all(32.0),
                child: Form(
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child:  InputWidget(
                              enabled:enabled,
                              kController: emailEditingController,
                            keyboardType: TextInputType.emailAddress,
                            onSaved: (String? value) {
                              // This optional block of code can be used to run
                              // code when the user saves the form.
                            },
                            onChanged: (String? value) {
                                print(emailEditingController.text);
                              // This optional block of code can be used to run
                              // code when the user saves the form.
                            },
                            validator: (String? value) {
                              return (value != null && value.contains('@'))
                                  ? 'Do not use the @ char.'
                                  : null;
                            },

                            topLabel: "Email",

                            hintText: "Enter E-mail",
                            // prefixIcon: FlutterIcons.chevron_left_fea,
                          ),
                          ),
                          Expanded(
                            flex: 2,
                            child:  InputWidget(
                              enabled:enabled,
                              kController: emailEditingController,
                              keyboardType: TextInputType.emailAddress,
                              onSaved: (String? value) {
                                // This optional block of code can be used to run
                                // code when the user saves the form.
                              },
                              onChanged: (String? value) {
                                print(emailEditingController.text);
                                // This optional block of code can be used to run
                                // code when the user saves the form.
                              },
                              validator: (String? value) {
                                return (value != null && value.contains('@'))
                                    ? 'Do not use the @ char.'
                                    : null;
                              },

                              topLabel: "Email",

                              hintText: "Enter E-mail",
                              // prefixIcon: FlutterIcons.chevron_left_fea,
                            ),),
                          SizedBox(
                            width: defaultPadding,
                          ),

                          Expanded(
                            flex: 2,
                            child:  InputWidget(
                              enabled:enabled,
                              kController: emailEditingController,
                              keyboardType: TextInputType.emailAddress,
                              onSaved: (String? value) {
                                // This optional block of code can be used to run
                                // code when the user saves the form.
                              },
                              onChanged: (String? value) {
                                print(emailEditingController.text);
                                // This optional block of code can be used to run
                                // code when the user saves the form.
                              },
                              validator: (String? value) {
                                return (value != null && value.contains('@'))
                                    ? 'Do not use the @ char.'
                                    : null;
                              },

                              topLabel: "Email",

                              hintText: "Enter E-mail",
                              // prefixIcon: FlutterIcons.chevron_left_fea,
                            ),),
                          SizedBox(
                            width: defaultPadding,
                          ),


                          Expanded(
                            flex: 2,
                            child:  InputWidget(
                              keyboardType: TextInputType.emailAddress,
                              onSaved: (String? value) {
                                // This optional block of code can be used to run
                                // code when the user saves the form.
                              },
                              onChanged: (String? value) {
                                // This optional block of code can be used to run
                                // code when the user saves the form.
                              },
                              validator: (String? value) {
                                return (value != null && value.contains('@'))
                                    ? 'Do not use the @ char.'
                                    : null;
                              },

                              topLabel: "Email",

                              hintText: "Enter E-mail",
                              // prefixIcon: FlutterIcons.chevron_left_fea,
                            ),)
                        ],
                      ),
                      Checkbox(value: selected, onChanged: (value){
                        setState(() {
                          selected =!selected;
                        });
                      }),
                  DropdownButton<String>(
                      value: dropdownValue,
                      icon: const Icon(Icons.arrow_downward),
                      iconSize: 24,
                      elevation: 16,
                      style: const TextStyle(
                          color: Colors.deepPurple
                      ),
                      underline: Container(
                        height: 2,
                        color: Colors.deepPurpleAccent,
                      ),
                      onChanged: (String? newValue) {
                        setState(() {
                          if(newValue=="oui"){
                            enabled = true;
                          } else{
                            enabled= false;
                          }
                          dropdownValue = newValue!;
                        });
                      },
                      items: check
                          .map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(value),
                        );
                      })
                      .toList(),
                  )
                    ],
                  ) ,
                ),
              ),
            ),
            ],
          ),
        ),
      ),
    );
  }
}
